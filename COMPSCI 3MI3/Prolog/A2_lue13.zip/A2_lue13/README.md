# Assignment 2

## Elite Lu | lue13 | 400364692

For this assignment, I decided to do the bonus for the goblin gnome solver. The names are as follows:

- Negation -> neg
- Exclusive or -> xor
- Implication -> implies

In addition to this, the test cases that were used were all created by tinkering with the terminal and seeing what would work.
Finally, part of the code for parts 1 and 3 were copied from the PowerPoint slides provided in class.
