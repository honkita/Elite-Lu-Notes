I would like to dedicate this area to the TAs of this class, especially Reed Mullanix and Jason Balaci. This is because Reed got a Discord call and explained the abomination that is this assignment. Jason texted me many clarification tips about the assignment and dealt alongside Reed with the out file. If it were not for them, I would have not finished.

UwU

here is a list of the peers I discussed concepts with
~ Ishpreet Nagi nagii
~ Kenneth Salim salimk4
~ Giovanna Gerada geradag
